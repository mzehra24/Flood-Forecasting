python Server.py
pause